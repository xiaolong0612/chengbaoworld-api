<?php

namespace app\common\services;


class MessageService
{

    /**
     * 发送消息
     *
     * @param string $messageType 消息类型
     * @param array $data 消息数据
     */
    public static function sendMessage(string $messageType, array $data = [])
    {
        switch ($messageType) {
        }
    }

}