<?php

namespace app\controller;

use app\BaseController;

class Index extends BaseController
{
}
