<?php

namespace app\controller\company\active\syn;

use app\common\repositories\active\syn\ActiveSynRepository;
use app\controller\company\Base;
use think\App;
use think\facade\Cache;

class Syn extends Base
{
    protected $repository;

    public function __construct(App $app, ActiveSynRepository $repository)
    {
        parent::__construct($app);
        $this->repository = $repository;
    }

    public function list()
    {

        if ($this->request->isAjax()) {
            $where = $this->request->param([
                'keywords' => '',
            ]);
            [$page, $limit] = $this->getPage();
            $data = $this->repository->getList($where,$page, $limit,$this->request->companyId);
            return json()->data(['code' => 0, 'data' => $data['list'],'count' => $data['count'] ]);
        }
        return $this->fetch('/active/syn/syn/list', [
            'addAuth' => company_auth('companyActiveSynAdd'),
            'editAuth' => company_auth('companyActiveSynEdit'),
            'delAuth' => company_auth('companyActiveSynDel'),
            'targetAuth' => company_auth('companyActiveSynTarget'),
            'materialAuth' => company_auth('companyActiveSynMaterial'),
            'importFileAuth' => company_auth('companyActiveSynUserImport'),
            'synMater' => company_auth('companySynMateriaList'),
        ]);
    }

    /**
     * 添加广告
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param([
                'title' => '',
                'syn_type' => '',
                'num' => '',
                'is_open' => '',
                'open_max' => '',
                'is_user' => '',
            ]);
            if(!$param['num'] || $param['num'] <= 0 ) $this->error('请输入合成材料数量!');
            if(!$param['title']) return $this->error('请输入合成标题');
            if(!$param['syn_type']) return $this->error('请选择合成类型');
            try {
                $res = $this->repository->addInfo($this->request->companyId,$param);
                if ($res) {
                    return $this->success('添加成功');
                } else {
                    return $this->error('添加失败');
                }
            } catch (\Exception $e) {
                return $this->error($e->getMessage());
            }
        } else {
            return $this->fetch('active/syn/syn/add');
        }
    }

    /**
     * 编辑广告
     */
    public function edit()
    {
        $id = $this->request->param('id');
        if (!$id) {
            return $this->error('参数错误');
        }
        $info = $this->repository->getDetail($id);
        if (!$info) {
            return $this->error('信息错误');
        }
        if ($this->request->isPost()) {
            $param = $this->request->param([
                'title' => '',
                'syn_type' => '',
                'num' => '',
                'is_open' => '',
                'is_user' => '',
                'open_max' => '',
            ]);
            if(!$param['num'] || $param['num'] <= 0 ) $this->error('请输入合成材料数量!');
            if(!$param['title']) return $this->error('请输入合成标题');
            if(!$param['syn_type']) return $this->error('请选择合成类型');
            try {
                $res = $this->repository->editInfo($info, $param);
                if ($res !== false) {
                    return $this->success('修改成功');
                } else {
                    return $this->error('修改失败');
                }
            } catch (\Exception $e) {
                return $this->error('网络失败');
            }
        } else {

            return $this->fetch('active/syn/syn/add', [
                'info' => $info,

            ]);
        }
    }


    /**
     * 设置状态
     */
    public function status()
    {
        $id = (int)$this->request->param('id');
        if ($this->request->isPost()) {
            $param = $this->request->param([
                'id' => '',
                'status' => '',
            ]);

            if (!$this->repository->exists($id)) {
                return $this->error('数据不存在');
            }
            try {
                $res = $this->repository->update($id, $param);
                admin_log(3, '修改合成状态 id:' . $id, $param);
                if ($res !== false) {
                    return $this->success('修改成功');
                } else {
                    return $this->error('修改失败');
                }
            } catch (\Exception $e) {
                return $this->error('网络错误');
            }
        }
    }


    /**
     * 删除广告
     */
    public function del()
    {
        $ids = (array)$this->request->param('ids');
        try {
            $data = $this->repository->batchDelete($ids);
            if ($data) {
                admin_log(4, '删除合成 ids:' . implode(',', $ids), $data);
                return $this->success('删除成功');
            } else {
                return $this->error('删除失败');
            }
        } catch (\Exception $e) {
            return $this->error('网络失败');
        }
    }

}